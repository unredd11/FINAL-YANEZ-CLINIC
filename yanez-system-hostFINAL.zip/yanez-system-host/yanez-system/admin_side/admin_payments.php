<?php
session_start();
date_default_timezone_set('Asia/Manila');
require '../components/connect.php';

// --- Restrict non-admin access ---
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit();
}

// --- Handle delete payment action ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'cancel_payment') {
    $appointment_id = intval($_POST['appointment_id'] ?? 0);

    // Delete payment record
    $delete = $conn->prepare("DELETE FROM appointment WHERE appointment_id=?");
    $delete->bind_param("i", $appointment_id);
    $delete->execute();
    $delete->close();

    // Show alert and redirect
    echo "<script>
        alert('❌ Appointment cancelled successfully (ID: {$appointment_id}).');
        window.location.href='admin_payments.php';
    </script>";
    exit();
}


// --- Filters ---
$search = $_GET['search'] ?? '';
$sort   = $_GET['sort'] ?? 'latest';

// --- Query with search & sort ---
// --- Sort by full datetime (date + time) ---
// --- Query with search & sort ---
if ($sort === 'earliest') {
    $orderBy = 'a.appointment_date ASC, a.appointment_time ASC';
} else {
    $orderBy = 'a.appointment_date DESC, a.appointment_time DESC';
}

$sql = "SELECT a.appointment_id, a.service, a.appointment_date, a.appointment_time,
               a.paypal_transaction_id, a.payment_method, a.status,
               CONCAT(p.first_name, ' ', p.last_name) AS patient_name,
               p.email
        FROM appointment a
        JOIN patient p ON a.patient_id = p.patient_id
        WHERE a.payment_method IN ('online','walkin')
          AND (p.first_name LIKE ? OR p.last_name LIKE ? OR a.service LIKE ?)
        ORDER BY $orderBy";

$stmt = $conn->prepare($sql);
$searchTerm = "%$search%";
$stmt->bind_param("sss", $searchTerm, $searchTerm, $searchTerm);
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();

// --- Summary Counts (exclude cancelled/rejected/declined) ---
$total_sql = "SELECT COUNT(*) AS total 
              FROM appointment 
              WHERE payment_method IN ('online','walkin')
                AND status NOT IN ('Cancelled','Rejected','Declined')";
$total = $conn->query($total_sql)->fetch_assoc()['total'] ?? 0;

$pending_sql = "SELECT COUNT(*) AS pending 
                FROM appointment 
                WHERE status='Pending' 
                  AND payment_method IN ('online','walkin')";
$pending = $conn->query($pending_sql)->fetch_assoc()['pending'] ?? 0;

// --- Revenue (exclude cancelled/rejected/declined) ---
$revenue_sql = "SELECT SUM(
                   CASE 
                     WHEN service='X-Ray' THEN 1000
                     WHEN service='Laboratory Testing' THEN 800
                     WHEN service='Physical Examination' THEN 500
                     ELSE 0
                   END
                ) AS total_revenue
                FROM appointment
                WHERE payment_method IN ('online','walkin')
                  AND status NOT IN ('Cancelled','Rejected','Declined')";

$revenue = $conn->query($revenue_sql)->fetch_assoc()['total_revenue'] ?? 0;

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin - Payments</title>
  <link rel="stylesheet" href="../css/yanezstyle.css">
</head>
<body>
<?php include 'admin_header.php'; ?>
<?php include 'admin_sidebar.php'; ?>

<div class="admin-content">

  <div class="admin-payments-container">
  <h2 style="text-align:center;color:#1e3c72;">Payments</h2>

  <!-- Summary Boxes -->
  <div class="summary-container">
    <div class="summary-box">
      <h3><?= $pending ?></h3>
      <p>Pending Payments</p>
    </div>
    <div class="summary-box">
      <h3>₱ <?= number_format($revenue, 2) ?></h3>
      <p>Total Revenue</p>
    </div>
    <div class="summary-box">
      <h3><?= $total ?></h3>
      <p>Total Payments</p>
    </div>
  </div>

  <!-- Search and Sort -->
  <form method="get" class="search-sort-bar">
  <div class="search-left">
    <input type="text" name="search" class="search-input" 
           placeholder="Search results..." 
           value="<?= htmlspecialchars($search ?? '') ?>">
    <button type="submit" class="search-btn">Search</button>
  </div>

    <div class="search-right">
      <select id="sort-btn" name="sort" onchange="this.form.submit()">
        <option value="latest" <?= ($sort === 'latest') ? 'selected' : '' ?>>Date (Latest First)</option>
        <option value="earliest" <?= ($sort === 'earliest') ? 'selected' : '' ?>>Date (Earliest First)</option>
      </select>
    </div>
  </form>

  <!-- Payments List -->
  <?php if ($result && $result->num_rows > 0): ?>
    <?php while($row = $result->fetch_assoc()): ?>
      <?php
        // Determine paid amount based on service
        switch ($row['service']) {
          case 'X-Ray':
            $paid_amount = 1000;
            break;
          case 'Laboratory Testing':
            $paid_amount = 800;
            break;
          case 'Physical Examination':
            $paid_amount = 500;
            break;
          default:
            $paid_amount = 0;
        }

        $formattedDateTime = date("F d, Y - h:i A", strtotime($row['appointment_date'].' '.$row['appointment_time']));
      ?>

      <div class="payment-card">
        <div class="payment-info">
          <div><strong>Patient:</strong> <?= htmlspecialchars($row['patient_name']) ?> (<?= htmlspecialchars($row['email']) ?>)</div>
          <div><strong>Service:</strong> <?= htmlspecialchars($row['service']) ?></div>
          <div><strong>Date/Time:</strong> <?= $formattedDateTime ?></div>
          <div><strong>Paid:</strong> ₱<?= number_format($paid_amount, 2) ?></div>
          <div><strong>Transaction:</strong> 
            <?php if ($row['payment_method'] === 'online'): ?>
              <?= htmlspecialchars($row['paypal_transaction_id']) ?>
            <?php else: ?>
              Walk-in (Pay at Clinic)
            <?php endif; ?>
          </div>
          <div><strong>Status:</strong> <?= htmlspecialchars($row['status']) ?></div>
        </div>

        <div class="payment-actions">
          <form method="post" onsubmit="return confirm('Are you sure you want to delete this payment?');">
            <input type="hidden" name="action" value="cancel_payment">
            <input type="hidden" name="appointment_id" value="<?= (int)$row['appointment_id'] ?>">
            <button type="submit" class="btn-cancel-payment">Delete Payment</button>
          </form>
        </div>
      </div>
    <?php endwhile; ?>
  <?php else: ?>
    <p style="text-align:center;">No PayPal payments found.</p>
  <?php endif; ?>
</div>
</div>

<script>
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('show');
}
</script>
</body>
</html>
