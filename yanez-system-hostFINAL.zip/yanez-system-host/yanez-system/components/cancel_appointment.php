<?php
session_start();
require 'connect.php'; 

if (!isset($_SESSION['patient_id'])) {
    header("Location: ../login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['appointment_id'])) {
    $appointment_id = intval($_POST['appointment_id']);
    $patient_id = $_SESSION['patient_id'];

    $sql = "UPDATE appointment 
            SET status = 'Cancelled', updated_at = NOW() 
            WHERE appointment_id = ? AND patient_id = ? AND status = 'Pending'";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $appointment_id, $patient_id);

    if ($stmt->execute()) {
        // Success: show alert and redirect back to patient history
        echo "<script>
            alert('❌ Appointment cancelled.');
            window.location.href='../patient_history.php';
        </script>";
        exit();
    } else {
        // Failure: show alert and redirect back
        echo "<script>
            alert('⚠️ Error cancelling appointment. Please try again.');
            window.location.href='../patient_history.php';
        </script>";
        exit();
    }
} else {
    header("Location: ../index.php");
    exit();
}
?>
