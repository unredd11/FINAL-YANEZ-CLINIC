<?php
session_start();
date_default_timezone_set('Asia/Manila');
require 'components/connect.php';

// Check if patient is logged in
if (!isset($_SESSION['user_logged_in']) || $_SESSION['user_logged_in'] !== true) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patient_id       = $_SESSION['patient_id'];
    $service          = $_POST['selectedService'];
    $appointment_date = $_POST['appointment_date'];
    $appointment_time = date("H:i:s", strtotime($_POST['selectedTime']));
    $status           = "Pending";
    $details          = $_POST['notes'];
    $payment_method   = $_POST['payment_method'];
    $paypal_txn       = $_POST['paypalTransactionId'] ?? null;

    // ✅ Prevent booking past date or time
    $currentDateTime = new DateTime('now', new DateTimeZone('Asia/Manila'));
    $selectedDateTime = new DateTime("$appointment_date $appointment_time", new DateTimeZone('Asia/Manila'));

    if ($selectedDateTime <= $currentDateTime) {
        echo "<script>alert('❌ You cannot book a past date or time. Please select a valid future slot.'); window.history.back();</script>";
        exit();
    }

    // ✅ Only proceed if date/time is valid
    $stmt = $conn->prepare("INSERT INTO appointment 
        (patient_id, service, appointment_date, appointment_time, status, appointment_details, payment_method, paypal_transaction_id) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssssss", $patient_id, $service, $appointment_date, $appointment_time, $status, $details, $payment_method, $paypal_txn);

    if ($stmt->execute()) {
        echo "<script>alert('✅ Appointment request submitted successfully!'); window.location='index.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Book Appointment - Yañez X-Ray Medical Clinic</title>
  <link rel="stylesheet" href="css/yanezstyle.css">
  <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
</head>
<body>
  <?php include 'header.php'; ?>

  <main class="bookappt-container">
    <h2 class="bookappt-title">Book Appointment</h2>

    <form action="book_appointment.php" method="POST" class="bookappt-form" onsubmit="return validateAppointment()">
      <table class="bookappt-table">
        <tr>
          <!-- Calendar (Date Picker) -->
          <td class="bookappt-left">
            <label for="appointment_date"><strong>Select Date</strong></label>
            <input type="date" id="appointment_date" name="appointment_date" required onchange="validateDate()">
            
            <h3>Available Time Slots</h3>
            <div class="bookappt-times">
              <select id="selectedTime" name="selectedTime" required>
              <option value="">-- Select Time Slot --</option>
              <option value="08:00 AM">07:30 AM</option>
              <option value="08:00 AM">08:00 AM</option>
              <option value="08:30 AM">08:30 AM</option>
              <option value="09:00 AM">09:00 AM</option>
              <option value="09:30 AM">09:30 AM</option>
              <option value="10:00 AM">10:00 AM</option>
              <option value="10:30 AM">10:30 AM</option>
              <option value="11:00 AM">11:00 AM</option>
              <option value="11:30 AM">11:30 AM</option>
              <option value="01:00 PM">01:00 PM</option>
              <option value="01:30 PM">01:30 PM</option>
              <option value="02:00 PM">02:00 PM</option>
              <option value="02:30 PM">02:30 PM</option>
              <option value="03:00 PM">03:00 PM</option>
              <option value="03:30 PM">03:30 PM</option>
              <option value="04:00 PM">04:00 PM</option>
            </select>
            </div>
          </td>

          <!-- Services & Payment -->
          <td class="bookappt-right">
            <h3>Select Service</h3>
            <select id="selectedService" name="selectedService" required>
              <option value="">-- Select a Service --</option>
              <option value="X-Ray">X-Ray</option>
              <option value="Laboratory Testing">Laboratory Testing</option>
              <option value="Physical Examination">Physical Examination</option>
            </select>

            <div class="bookappt-payment">
              <label><strong>Payment Method</strong></label><br>
              <label><input type="radio" name="payment_method" value="online" required onclick="togglePayment('online')"> Pay Online (PayPal)</label><br>
              <div id="paypal-button-container" style="margin-top:10px; display:none;"></div>
              <label><input type="radio" name="payment_method" value="walkin" required onclick="togglePayment('walkin')"> Pay at Clinic (Walk-in)</label>
            </div>

            <input type="hidden" name="paypalTransactionId" id="paypalTransactionId">

            <label for="notes"><strong>Additional Details</strong></label>
            <textarea id="notes" name="notes" rows="3" placeholder="Please provide a short any additional details about your condition or special requests"></textarea>

            <button type="submit" class="bookappt-submit">Book Appointment</button>

            <div class="bookappt-notice">
              <h3>Important Notice</h3>
              <p>Please double-check your selected date, time, and payment details before submitting your appointment.</p>
            </div>
          </td>
        </tr>
      </table>
    </form>
  </main>

  <?php include "footer.php"; ?>

<script src="https://www.paypal.com/sdk/js?client-id=AZN_Kd-eiU1lxoWa6qgv4pxex1yO6PCzTV_ajfvSTdDagPTh2MF1wDCs38WAljyFzZ4GLvixT07swvha&currency=PHP"></script>

  <script>
  const dateInput = document.getElementById('appointment_date');
  const timeSelect = document.getElementById('selectedTime');
  const today = new Date().toISOString().split('T')[0];
  dateInput.setAttribute('min', today);

  // Disallow Sundays + adjust Saturday slots
  function validateDate() {
    const selected = new Date(dateInput.value);
    const day = selected.getDay();

    if (day === 0) {
      alert("The clinic is closed on Sundays. Please choose another date.");
      dateInput.value = "";
      return;
    }
  }

  function validateAppointment() {
  const selectedDate = new Date(document.getElementById('appointment_date').value);
  const selectedTimeStr = document.getElementById('selectedTime').value;
  const selectedService = document.getElementById('selectedService').value;

  if (!selectedDate || !selectedTimeStr || !selectedService) {
    alert("⚠️ Please complete all fields before booking.");
    return false;
  }

  const now = new Date();
  const isToday = selectedDate.toDateString() === now.toDateString();

  // Convert selected time to 24-hour
  const [time, meridiem] = selectedTimeStr.split(' ');
  let [hours, minutes] = time.split(':').map(Number);
  if (meridiem === 'PM' && hours < 12) hours += 12;
  if (meridiem === 'AM' && hours === 12) hours = 0;

  // Build full DateTime for selected appointment
  const selectedDateTime = new Date(selectedDate);
  selectedDateTime.setHours(hours, minutes, 0, 0);

  // Restrict Sunday
  if (selectedDate.getDay() === 0) {
    alert("❌ The clinic is closed on Sundays.");
    return false;
  }

  // Restrict Saturday afternoon
  if (selectedDate.getDay() === 6 && hours >= 17) {
    alert("⚠️ On Saturdays, the last available slot is before 5:00 PM.");
    return false;
  }

  // Prevent past time booking today
  if (isToday && selectedDateTime <= now) {
    alert("❌ You cannot book a time that has already passed today.");
    return false;
  }

  // Prevent past date booking
  if (selectedDate < new Date(now.toDateString())) {
    alert("❌ You cannot book on a past date.");
    return false;
  }

  return true;
}

  // PayPal integration
  function togglePayment(method) {
    const paypalContainer = document.getElementById('paypal-button-container');
    paypalContainer.innerHTML = '';
    if (method === 'online') {
      paypalContainer.style.display = 'block';
      paypal.Buttons({
        createOrder: function(data, actions) {
          let service = document.getElementById('selectedService').value;
          let amount = 0;
          if (service === "X-Ray") amount = 1000;
          if (service === "Laboratory Testing") amount = 800;
          if (service === "Physical Examination") amount = 500;
          return actions.order.create({
            purchase_units: [{ amount: { value: amount.toFixed(2) }, description: service + " Appointment" }]
          });
        },
        onApprove: function(data, actions) {
          return actions.order.capture().then(function(details) {
            document.getElementById('paypalTransactionId').value = details.id;
            alert('Payment completed by ' + details.payer.name.given_name);
            document.querySelector('.bookappt-form').submit();
          });
        }
      }).render('#paypal-button-container');
    } else {
      paypalContainer.style.display = 'none';
    }
  }
  function toggleNav() {
  var navMenu = document.getElementById('navMenu');
  if (navMenu) navMenu.classList.toggle('show');
}
</script>
</body>
</html>
