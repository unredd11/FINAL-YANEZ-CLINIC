<?php
session_start();
require 'connect.php'; // make sure connect.php is in the same folder (components)

if (!isset($_SESSION['patient_id'])) {
    header("Location: ../login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['appointment_id'])) {
    $appointment_id = intval($_POST['appointment_id']);
    $patient_id = $_SESSION['patient_id'];

    // Update appointment status to "Cancelled" (only if it's still Pending)
    $sql = "UPDATE appointment 
            SET status = 'Cancelled', updated_at = NOW() 
            WHERE appointment_id = ? AND patient_id = ? AND status = 'Pending'";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $appointment_id, $patient_id);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Your appointment has been cancelled successfully.";
    } else {
        $_SESSION['message'] = "Error cancelling appointment. Please try again.";
    }

    // Redirect back to patient profile
    header("Location: ../index.php");
    exit();
} else {
    header("Location: ../index.php");
    exit();
}
?>
