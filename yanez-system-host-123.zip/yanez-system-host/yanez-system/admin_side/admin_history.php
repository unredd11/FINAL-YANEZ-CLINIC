<?php
session_start();
require '../components/connect.php';

// Security check
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: admin_login.php");
    exit();
}

// Handle delete PDF file
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);

    // Fetch file name first
    $stmt = $conn->prepare("SELECT result_file FROM results WHERE result_id = ?");
    $stmt->bind_param("i", $delete_id);
    $stmt->execute();
    $stmt->bind_result($file);
    $stmt->fetch();
    $stmt->close();

    // Delete file from directory if exists
    if ($file && file_exists("../patient_side/uploads/" . $file)) {
        unlink("../patient_side/uploads/" . $file);
    }

    // Delete record from DB
    $delete = $conn->prepare("DELETE FROM results WHERE result_id = ?");
    $delete->bind_param("i", $delete_id);
    $delete->execute();

    echo "<script>
        alert('PDF record deleted successfully!');
        window.location.href='admin_history.php';
    </script>";
    exit();
}

// === SEARCH & SORT LOGIC ===
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$sort_order = isset($_GET['sort']) ? $_GET['sort'] : 'DESC';

$sql = "SELECT r.result_id, r.result_file, r.result_text, r.created_at,
               CONCAT(p.first_name, ' ', p.last_name) AS patient_name,
               a.service, a.payment_method
        FROM results r
        JOIN patient p ON r.patient_id = p.patient_id
        JOIN appointment a ON r.appointment_id = a.appointment_id
        WHERE (CONCAT(p.first_name, ' ', p.last_name) LIKE ? OR a.service LIKE ?)
        ORDER BY r.created_at $sort_order";

$stmt = $conn->prepare($sql);
$like_search = '%' . $search . '%';
$stmt->bind_param('ss', $like_search, $like_search);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin History - Results</title>
  <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../css/yanezstyle.css">
</head>
<body>

<?php include '../admin_side/admin_header.php'; ?>
<?php include '../admin_side/admin_sidebar.php'; ?>

  <div class="history-container">
    <h2 class="history-title">Admin History</h2>

<!-- Search + Sort Form -->
<form method="get" class="search-sort-bar">
  <div class="search-left">
    <input type="text" name="search" class="search-input" 
           placeholder="Search results..." 
           value="<?= htmlspecialchars($search ?? '') ?>">
    <button type="submit" class="search-btn">Search</button>
  </div>

  <div class="search-right">
    <select id="sort-btn" name="sort" onchange="this.form.submit()">
      <option value="DESC" <?= $sort_order === 'DESC' ? 'selected' : '' ?>>Date (Latest First)</option>
      <option value="ASC" <?= $sort_order === 'ASC' ? 'selected' : '' ?>>Date (Earliest First)</option>
    </select>
  </div>
</form>


    <table class="admin-users-table">
      <thead>
        <tr>
          <th>Patient Name</th>
          <th>Service</th>
          <th>Payment</th>
          <th>Amount</th>
          <th>Released Date</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($result && $result->num_rows > 0): ?>
          <?php 
          // Price map
          $prices = [
            'X-Ray' => 1000,
            'Laboratory Testing' => 800,
            'Physical Examination' => 500
          ];
          ?>
          <?php while ($row = $result->fetch_assoc()): ?>
            <?php 
              $method = $row['payment_method'] === 'online' ? 'PayPal' : 'Walk-in';
              $amount = $prices[$row['service']] ?? 0;
            ?>
            <tr>
              <td><?= htmlspecialchars($row['patient_name']) ?></td>
              <td><?= htmlspecialchars($row['service']) ?></td>
              <td><?= $method ?></td>
              <td>₱<?= number_format($amount, 2) ?></td>
              <td><?= date("F d, Y h:i A", strtotime($row['created_at'])) ?></td>
              <td>
                <?php if (!empty($row['result_file'])): ?>
                  <div class="admin-history-buttons">
                  <a class="view-btn" target="_blank" href="../patient_side/uploads/<?= htmlspecialchars($row['result_file']) ?>">View PDF</a>
                <?php else: ?>
                  <span style="color:gray;">No File</span>
                <?php endif; ?>
                <a class="delete-btn" href="admin_history.php?delete_id=<?= $row['result_id'] ?>" onclick="return confirm('Are you sure you want to delete this result?')">Delete</a>
                </div>
              </td>
            </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr><td colspan="6">No results found.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

<script>
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('show');
}
</script>

</body>
</html>
